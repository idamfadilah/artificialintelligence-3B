# kecerdasanbuatan
Modul Praktikum Kecerdasan Buatan
